
  # Registro de usuario

  This is a code bundle for Registro de usuario. The original project is available at https://www.figma.com/design/wB4vdJ0Wfn5Mqsm5wrdo3y/Registro-de-usuario.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  