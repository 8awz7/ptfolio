import { Outlet, Link, useLocation } from 'react-router';
import { User, Zap, Mail, LogIn, Sun, Moon } from 'lucide-react';
import { useState } from 'react';

export function Layout() {
  const location = useLocation();
  const isLoginPage = location.pathname === '/';
  const [isDarkMode, setIsDarkMode] = useState(true);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  if (isLoginPage) {
    return <Outlet />;
  }

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-black' : 'bg-white'}`}>
      {/* Navegación */}
      <nav className={`${isDarkMode ? 'bg-zinc-900 border-zinc-800' : 'bg-gray-100 border-gray-300'} border-b`}>
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/about" className="flex items-center gap-2">
              <div className="text-2xl font-bold text-[#c8ff00]">BAWS</div>
            </Link>

            {/* Links de navegación */}
            <div className="flex items-center gap-6">
              <NavLink to="/about" icon={User} label="Sobre Mí" isDarkMode={isDarkMode} />
              <NavLink to="/skills" icon={Zap} label="Habilidades" isDarkMode={isDarkMode} />
              <NavLink to="/contact" icon={Mail} label="Contacto" isDarkMode={isDarkMode} />
              
              {/* Botón de toggle de tema */}
              <button
                onClick={toggleTheme}
                className={`flex items-center gap-2 ${
                  isDarkMode ? 'text-zinc-400 hover:text-[#c8ff00]' : 'text-gray-600 hover:text-[#c8ff00]'
                } transition-colors p-2 rounded-lg ${
                  isDarkMode ? 'hover:bg-zinc-800' : 'hover:bg-gray-200'
                }`}
                title={isDarkMode ? 'Activar Modo Claro' : 'Activar Modo Oscuro'}
              >
                {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>

              <Link
                to="/"
                className={`flex items-center gap-2 ${
                  isDarkMode ? 'text-zinc-400 hover:text-[#c8ff00]' : 'text-gray-600 hover:text-[#c8ff00]'
                } transition-colors`}
              >
                <LogIn className="w-4 h-4" />
                <span className="text-sm">Salir</span>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Contenido */}
      <div className={isDarkMode ? '' : 'text-black'}>
        <Outlet context={{ isDarkMode }} />
      </div>
    </div>
  );
}

function NavLink({ to, icon: Icon, label, isDarkMode }: { to: string; icon: any; label: string; isDarkMode: boolean }) {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <Link
      to={to}
      className={`flex items-center gap-2 transition-colors ${
        isActive
          ? 'text-[#c8ff00] font-semibold'
          : isDarkMode 
            ? 'text-zinc-400 hover:text-[#c8ff00]'
            : 'text-gray-600 hover:text-[#c8ff00]'
      }`}
    >
      <Icon className="w-4 h-4" />
      <span className="text-sm">{label}</span>
    </Link>
  );
}