import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { useState } from 'react';

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // Aquí iría la lógica de envío del formulario
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="container mx-auto px-4 py-16 max-w-6xl">
      {/* Header */}
      <div className="text-center mb-16">
        <h1 className="text-5xl font-bold text-white mb-4">
          PONTE EN <span className="text-[#c8ff00]">CONTACTO</span>
        </h1>
        <div className="h-1 w-32 bg-[#c8ff00] mx-auto mb-6"></div>
        <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
          ¿Tienes un proyecto en mente? Me encantaría escuchar tus ideas y 
          colaborar en crear algo increíble juntos.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 mb-16">
        {/* Información de contacto */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-8">
            Información de <span className="text-[#c8ff00]">Contacto</span>
          </h2>

          {/* Email */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 mb-6 hover:border-[#c8ff00] transition-all duration-300">
            <div className="flex items-start gap-4">
              <div className="bg-[#c8ff00] p-3 rounded-lg">
                <Mail className="w-6 h-6 text-black" />
              </div>
              <div>
                <h3 className="text-white font-semibold mb-1">Email</h3>
                <a 
                  href="mailto:contacto@baws.design"
                  className="text-zinc-400 hover:text-[#c8ff00] transition-colors"
                >
                  contacto@baws.design
                </a>
              </div>
            </div>
          </div>

          {/* Teléfono */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 mb-6 hover:border-[#c8ff00] transition-all duration-300">
            <div className="flex items-start gap-4">
              <div className="bg-[#c8ff00] p-3 rounded-lg">
                <Phone className="w-6 h-6 text-black" />
              </div>
              <div>
                <h3 className="text-white font-semibold mb-1">Teléfono</h3>
                <a 
                  href="tel:+1234567890"
                  className="text-zinc-400 hover:text-[#c8ff00] transition-colors"
                >
                  +1 (234) 567-890
                </a>
              </div>
            </div>
          </div>

          {/* Ubicación */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 mb-8 hover:border-[#c8ff00] transition-all duration-300">
            <div className="flex items-start gap-4">
              <div className="bg-[#c8ff00] p-3 rounded-lg">
                <MapPin className="w-6 h-6 text-black" />
              </div>
              <div>
                <h3 className="text-white font-semibold mb-1">Ubicación</h3>
                <p className="text-zinc-400">
                  Ciudad de México, México
                </p>
              </div>
            </div>
          </div>

          {/* Redes Sociales */}
          <div>
            <h3 className="text-white font-semibold mb-4">Sígueme en Redes Sociales</h3>
            <div className="flex gap-4">
              {/* Instagram */}
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-zinc-900 border border-zinc-800 hover:border-[#c8ff00] p-4 rounded-lg transition-all duration-300 hover:bg-[#c8ff00] group"
              >
                <svg
                  className="w-6 h-6 text-[#c8ff00] group-hover:text-black transition-colors"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </a>

              {/* Behance */}
              <a
                href="https://behance.net"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-zinc-900 border border-zinc-800 hover:border-[#c8ff00] p-4 rounded-lg transition-all duration-300 hover:bg-[#c8ff00] group"
              >
                <svg
                  className="w-6 h-6 text-[#c8ff00] group-hover:text-black transition-colors"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M6.938 4.503c.702 0 1.34.06 1.92.188.577.13 1.07.33 1.485.61.41.28.733.65.96 1.12.225.47.34 1.05.34 1.73 0 .74-.17 1.36-.507 1.86-.338.5-.837.9-1.502 1.22.906.26 1.576.72 2.022 1.37.448.66.665 1.45.665 2.36 0 .75-.13 1.39-.41 1.93-.28.55-.67 1-1.16 1.35-.48.348-1.05.6-1.67.767-.61.165-1.252.25-1.91.25H0V4.51h6.938v-.007zM16.94 16.665c.44.428 1.073.643 1.894.643.59 0 1.1-.148 1.53-.447.424-.29.68-.61.78-.94h2.588c-.403 1.28-1.048 2.2-1.9 2.75-.85.56-1.884.83-3.08.83-.837 0-1.584-.13-2.272-.4-.673-.27-1.24-.65-1.72-1.14-.464-.49-.823-1.08-1.077-1.77-.253-.69-.373-1.45-.373-2.27 0-.803.135-1.54.403-2.23.27-.7.644-1.28 1.12-1.79.495-.51 1.063-.895 1.736-1.194.673-.3 1.405-.45 2.184-.45.86 0 1.608.16 2.278.48.67.324 1.215.75 1.66 1.29.44.545.78 1.177.994 1.906.21.73.315 1.503.315 2.33 0 .077-.007.19-.007.34H14.27c0 .87.256 1.64.77 2.08zm-.107-7.013c-.355-.295-.935-.443-1.452-.443-.426 0-.773.064-1.04.19-.267.13-.48.295-.636.495-.154.202-.255.423-.3.665-.043.243-.067.465-.073.67h4.558c-.07-.813-.36-1.31-.767-1.574zM15.95 5.81h4.742v1.184H15.95V5.81z" />
                </svg>
              </a>

              {/* Dribbble */}
              <a
                href="https://dribbble.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-zinc-900 border border-zinc-800 hover:border-[#c8ff00] p-4 rounded-lg transition-all duration-300 hover:bg-[#c8ff00] group"
              >
                <svg
                  className="w-6 h-6 text-[#c8ff00] group-hover:text-black transition-colors"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 0C5.37 0 0 5.37 0 12s5.37 12 12 12 12-5.37 12-12S18.63 0 12 0zm8.7 4.86c1.5 1.87 2.4 4.24 2.42 6.82-.32-.07-3.5-.7-6.7-.31-.13-.32-.27-.65-.42-1-.43-1.09-.9-2.16-1.4-3.2 3.37-1.39 4.9-3.41 5.1-3.71v.4zM12 2.17c2.7 0 5.16 1.03 7.02 2.71-.18.27-1.54 2.13-4.77 3.38-1.45-2.67-3.06-4.85-3.3-5.19.34-.05.68-.08 1.05-.08v-.82zM8.55 3.08c.24.33 1.83 2.51 3.3 5.14-4.16 1.11-7.83 1.09-8.23 1.09.55-2.78 2.26-5.11 4.93-6.23zM2.17 12v-.31c.4.01 4.85.06 9.31-1.29.48 1.17.94 2.34 1.36 3.52-4.77 1.34-7.31 5.04-7.54 5.38-1.87-1.87-3.02-4.45-3.02-7.3h-.11zm9.83 9.83c-2.4 0-4.63-.87-6.34-2.32.18-.33 2.05-3.56 7.31-5.21l.07-.02c1.17 3.03 1.65 5.58 1.77 6.3-1.11.53-2.34.83-3.66.83l.85.42zm5.58-1.44c-.09-.53-.52-2.93-1.58-5.92 3-.48 5.63.31 5.95.4-.42 2.57-1.87 4.78-4.01 6.19l-.36-.67z" />
                </svg>
              </a>

              {/* LinkedIn */}
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-zinc-900 border border-zinc-800 hover:border-[#c8ff00] p-4 rounded-lg transition-all duration-300 hover:bg-[#c8ff00] group"
              >
                <svg
                  className="w-6 h-6 text-[#c8ff00] group-hover:text-black transition-colors"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                </svg>
              </a>

              {/* Twitter/X */}
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-zinc-900 border border-zinc-800 hover:border-[#c8ff00] p-4 rounded-lg transition-all duration-300 hover:bg-[#c8ff00] group"
              >
                <svg
                  className="w-6 h-6 text-[#c8ff00] group-hover:text-black transition-colors"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </a>
            </div>
          </div>
        </div>

        {/* Formulario de contacto */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-8">
            Envía un <span className="text-[#c8ff00]">Mensaje</span>
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Nombre */}
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-zinc-400 mb-2">
                Nombre
              </label>
              <input
                id="name"
                name="name"
                type="text"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-zinc-900 border border-zinc-800 rounded-lg text-white placeholder-zinc-600 focus:outline-none focus:border-[#c8ff00] focus:ring-2 focus:ring-[#c8ff00]/20 transition-all"
                placeholder="Tu nombre completo"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-zinc-400 mb-2">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-zinc-900 border border-zinc-800 rounded-lg text-white placeholder-zinc-600 focus:outline-none focus:border-[#c8ff00] focus:ring-2 focus:ring-[#c8ff00]/20 transition-all"
                placeholder="tu@email.com"
                required
              />
            </div>

            {/* Asunto */}
            <div>
              <label htmlFor="subject" className="block text-sm font-medium text-zinc-400 mb-2">
                Asunto
              </label>
              <input
                id="subject"
                name="subject"
                type="text"
                value={formData.subject}
                onChange={handleChange}
                className="w-full px-4 py-3 bg-zinc-900 border border-zinc-800 rounded-lg text-white placeholder-zinc-600 focus:outline-none focus:border-[#c8ff00] focus:ring-2 focus:ring-[#c8ff00]/20 transition-all"
                placeholder="¿De qué se trata?"
                required
              />
            </div>

            {/* Mensaje */}
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-zinc-400 mb-2">
                Mensaje
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows={5}
                className="w-full px-4 py-3 bg-zinc-900 border border-zinc-800 rounded-lg text-white placeholder-zinc-600 focus:outline-none focus:border-[#c8ff00] focus:ring-2 focus:ring-[#c8ff00]/20 transition-all resize-none"
                placeholder="Cuéntame sobre tu proyecto..."
                required
              />
            </div>

            {/* Botón de envío */}
            <button
              type="submit"
              className="w-full bg-[#c8ff00] hover:bg-[#deff4d] text-black font-bold py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 shadow-lg shadow-[#c8ff00]/20 hover:shadow-[#c8ff00]/40"
            >
              <Send className="w-5 h-5" />
              Enviar Mensaje
            </button>
          </form>
        </div>
      </div>

      {/* Llamada a la acción */}
      <div className="bg-gradient-to-r from-zinc-900 to-black border border-zinc-800 rounded-2xl p-12 text-center">
        <h3 className="text-3xl font-bold text-white mb-4">
          ¿Listo para trabajar juntos?
        </h3>
        <p className="text-zinc-400 text-lg mb-6">
          Transformemos tus ideas en diseños extraordinarios
        </p>
        <a
          href="mailto:contacto@baws.design"
          className="inline-block bg-[#c8ff00] hover:bg-[#deff4d] text-black font-bold py-3 px-8 rounded-lg transition-all duration-200 shadow-lg shadow-[#c8ff00]/20 hover:shadow-[#c8ff00]/40"
        >
          Comencemos un Proyecto
        </a>
      </div>
    </div>
  );
}
