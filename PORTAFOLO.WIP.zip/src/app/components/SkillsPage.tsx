import { Pencil, Box, Lightbulb, Layers } from 'lucide-react';
import logoImage from 'figma:asset/a3eb0e0f39747d41e90a91967dce309492d42f08.png';
import clipStudioLogo from 'figma:asset/ac941239847eca4a5c67e5477299c45ef2d8016c.png';
import blenderLogo from 'figma:asset/f41e18a533e1784b9f991db600ea04a45c8ed462.png';
import paintToolSaiLogo from 'figma:asset/625e268c24d588333e101425a2e949e487822963.png';

export function SkillsPage() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-7xl">
      {/* Logo y título */}
      <div className="text-center mb-16">
        <div className="flex justify-center mb-6">
          <img src={logoImage} alt="BAWS Logo" className="h-24" />
        </div>
        <h1 className="text-5xl font-bold text-white mb-4">
          MIS <span className="text-[#c8ff00]">HABILIDADES</span>
        </h1>
        <div className="h-1 w-32 bg-[#c8ff00] mx-auto"></div>
      </div>

      {/* Grid de habilidades principales */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
        {/* Dibujo y Observación */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 hover:border-[#c8ff00] transition-all duration-300">
          <div className="flex justify-center mb-4">
            <Pencil className="w-12 h-12 text-[#c8ff00]" />
          </div>
          <h3 className="text-[#c8ff00] font-bold text-center mb-3 text-sm">
            DIBUJO Y OBSERVACIÓN
          </h3>
          <p className="text-zinc-400 text-sm text-center leading-relaxed">
            Capacidad excepcional para capturar detalles y traducir conceptos visuales 
            desde la observación a la práctica.
          </p>
        </div>

        {/* Composición */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 hover:border-[#c8ff00] transition-all duration-300">
          <div className="flex justify-center mb-4">
            <Box className="w-12 h-12 text-[#c8ff00]" />
          </div>
          <h3 className="text-[#c8ff00] font-bold text-center mb-3 text-sm">
            COMPOSICIÓN
          </h3>
          <p className="text-zinc-400 text-sm text-center leading-relaxed">
            Dominio de los principios de diseño para crear trabajos visuales 
            equilibrados y dinámicos que guíen la mirada del espectador.
          </p>
        </div>

        {/* Color y Luz */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 hover:border-[#c8ff00] transition-all duration-300">
          <div className="flex justify-center mb-4">
            <Lightbulb className="w-12 h-12 text-[#c8ff00]" />
          </div>
          <h3 className="text-[#c8ff00] font-bold text-center mb-3 text-sm">
            COLOR Y LUZ
          </h3>
          <p className="text-zinc-400 text-sm text-center leading-relaxed">
            Comprensión profunda de la teoría del color y cómo la luz afecta 
            la percepción visual para crear atmósferas únicas.
          </p>
        </div>

        {/* Técnicas Variadas */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 hover:border-[#c8ff00] transition-all duration-300">
          <div className="flex justify-center mb-4">
            <Layers className="w-12 h-12 text-[#c8ff00]" />
          </div>
          <h3 className="text-[#c8ff00] font-bold text-center mb-3 text-sm">
            TÉCNICAS VARIADAS
          </h3>
          <p className="text-zinc-400 text-sm text-center leading-relaxed">
            Versatilidad en múltiples estilos y técnicas, desde ilustración 
            tradicional hasta diseño digital y 3D.
          </p>
        </div>
      </div>

      {/* Sección de Programas */}
      <div className="mb-16">
        <h2 className="text-4xl font-bold text-white text-center mb-12">
          PROGRAMAS
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {/* Clip Studio Paint */}
          <div className="group">
            <div className="bg-black border-2 border-[#c8ff00] rounded-xl p-8 aspect-square flex items-center justify-center mb-4 hover:bg-[#c8ff00] transition-all duration-300">
              <img 
                src={clipStudioLogo} 
                alt="Clip Studio Paint Logo" 
                className="w-full h-full object-contain group-hover:scale-110 transition-transform"
              />
            </div>
            <div className="bg-[#c8ff00] py-2 px-4 text-center rounded-lg">
              <p className="text-black font-bold text-sm">CLIP STUDIO PAINT</p>
            </div>
          </div>

          {/* Photoshop */}
          <div className="group">
            <div className="bg-black border-2 border-[#c8ff00] rounded-xl p-8 aspect-square flex items-center justify-center mb-4 hover:bg-[#c8ff00] transition-all duration-300">
              <div className="text-[#c8ff00] group-hover:text-black font-bold text-6xl transition-colors">
                Ps
              </div>
            </div>
            <div className="bg-[#c8ff00] py-2 px-4 text-center rounded-lg">
              <p className="text-black font-bold text-sm">PHOTOSHOP</p>
            </div>
          </div>

          {/* Blender */}
          <div className="group">
            <div className="bg-black border-2 border-[#c8ff00] rounded-xl p-8 aspect-square flex items-center justify-center mb-4 hover:bg-[#c8ff00] transition-all duration-300">
              <img 
                src={blenderLogo} 
                alt="Blender Logo" 
                className="w-full h-full object-contain group-hover:scale-110 transition-transform"
              />
            </div>
            <div className="bg-[#c8ff00] py-2 px-4 text-center rounded-lg">
              <p className="text-black font-bold text-sm">BLENDER</p>
            </div>
          </div>

          {/* Paint Tool SAI */}
          <div className="group">
            <div className="bg-black border-2 border-[#c8ff00] rounded-xl p-8 aspect-square flex items-center justify-center mb-4 hover:bg-[#c8ff00] transition-all duration-300">
              <img 
                src={paintToolSaiLogo} 
                alt="Paint Tool SAI Logo" 
                className="w-full h-full object-contain group-hover:scale-110 transition-transform"
              />
            </div>
            <div className="bg-[#c8ff00] py-2 px-4 text-center rounded-lg">
              <p className="text-black font-bold text-sm">PAINT TOOL SAI</p>
            </div>
          </div>
        </div>
      </div>

      {/* Estadísticas */}
      <div className="grid md:grid-cols-3 gap-8 bg-zinc-900 border border-zinc-800 rounded-2xl p-8">
        <div className="text-center">
          <div className="text-5xl font-bold text-[#c8ff00] mb-2">5+</div>
          <div className="text-zinc-400">Años de Experiencia</div>
        </div>
        <div className="text-center">
          <div className="text-5xl font-bold text-[#c8ff00] mb-2">100+</div>
          <div className="text-zinc-400">Proyectos Completados</div>
        </div>
        <div className="text-center">
          <div className="text-5xl font-bold text-[#c8ff00] mb-2">4</div>
          <div className="text-zinc-400">Herramientas Dominadas</div>
        </div>
      </div>
    </div>
  );
}