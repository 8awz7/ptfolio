import { ImageWithFallback } from './figma/ImageWithFallback';
import { Palette, Eye, Sparkles } from 'lucide-react';
import { useOutletContext } from 'react-router';

export function AboutPage() {
  const { isDarkMode } = useOutletContext<{ isDarkMode: boolean }>();

  return (
    <div className="container mx-auto px-4 py-16 max-w-6xl">
      {/* Hero Section */}
      <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
        {/* Imagen */}
        <div className="relative">
          <div className="absolute inset-0 bg-[#c8ff00] opacity-20 blur-3xl rounded-full"></div>
          <div className="relative rounded-2xl overflow-hidden border-4 border-[#c8ff00] shadow-2xl shadow-[#c8ff00]/20">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1526242767279-2ad8d8271177?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ25lciUyMHdvcmtzcGFjZSUyMGNyZWF0aXZlJTIwc3R1ZGlvfGVufDF8fHx8MTc3MTI4MDc4Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Designer Workspace"
              className="w-full h-[400px] object-cover"
            />
          </div>
        </div>

        {/* Texto */}
        <div>
          <div className="inline-block bg-[#c8ff00] text-black px-4 py-1 rounded-full text-sm font-bold mb-4">
            DISEÑADOR VISUAL
          </div>
          <h1 className={`text-5xl font-bold ${isDarkMode ? 'text-white' : 'text-black'} mb-6`}>
            Creando Experiencias
            <span className="text-[#c8ff00]"> Visuales</span>
          </h1>
          <div className="h-1 w-32 bg-[#c8ff00] mb-6"></div>
          <p className={`${isDarkMode ? 'text-zinc-400' : 'text-gray-600'} text-lg leading-relaxed mb-6`}>
            Soy un diseñador enfocado en crear experiencias visuales impactantes y memorables. 
            Mi trabajo se centra en la intersección entre el arte y la funcionalidad, donde cada 
            píxel cuenta una historia.
          </p>
          <p className={`${isDarkMode ? 'text-zinc-400' : 'text-gray-600'} text-lg leading-relaxed`}>
            Con una pasión por la innovación y el detalle, transformo ideas en diseños que no 
            solo se ven increíbles, sino que también comunican efectivamente el mensaje de cada proyecto.
          </p>
        </div>
      </div>

      {/* Sección de Enfoque */}
      <div className="mb-20">
        <h2 className={`text-3xl font-bold ${isDarkMode ? 'text-white' : 'text-black'} mb-12 text-center`}>
          Mi <span className="text-[#c8ff00]">Enfoque</span>
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {/* Card 1 */}
          <div className={`${isDarkMode ? 'bg-zinc-900 border-zinc-800' : 'bg-gray-50 border-gray-300'} border rounded-xl p-8 hover:border-[#c8ff00] transition-all duration-300 hover:shadow-lg hover:shadow-[#c8ff00]/10`}>
            <div className="w-16 h-16 bg-[#c8ff00] rounded-lg flex items-center justify-center mb-6">
              <Palette className="w-8 h-8 text-black" />
            </div>
            <h3 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-black'} mb-4`}>Diseño Centrado</h3>
            <p className={`${isDarkMode ? 'text-zinc-400' : 'text-gray-600'} leading-relaxed`}>
              Cada proyecto comienza con una comprensión profunda de las necesidades del usuario 
              y los objetivos visuales que queremos alcanzar.
            </p>
          </div>

          {/* Card 2 */}
          <div className={`${isDarkMode ? 'bg-zinc-900 border-zinc-800' : 'bg-gray-50 border-gray-300'} border rounded-xl p-8 hover:border-[#c8ff00] transition-all duration-300 hover:shadow-lg hover:shadow-[#c8ff00]/10`}>
            <div className="w-16 h-16 bg-[#c8ff00] rounded-lg flex items-center justify-center mb-6">
              <Eye className="w-8 h-8 text-black" />
            </div>
            <h3 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-black'} mb-4`}>Atención al Detalle</h3>
            <p className={`${isDarkMode ? 'text-zinc-400' : 'text-gray-600'} leading-relaxed`}>
              Los pequeños detalles hacen la diferencia. Me aseguro de que cada elemento visual 
              esté perfectamente alineado con la visión del proyecto.
            </p>
          </div>

          {/* Card 3 */}
          <div className={`${isDarkMode ? 'bg-zinc-900 border-zinc-800' : 'bg-gray-50 border-gray-300'} border rounded-xl p-8 hover:border-[#c8ff00] transition-all duration-300 hover:shadow-lg hover:shadow-[#c8ff00]/10`}>
            <div className="w-16 h-16 bg-[#c8ff00] rounded-lg flex items-center justify-center mb-6">
              <Sparkles className="w-8 h-8 text-black" />
            </div>
            <h3 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-black'} mb-4`}>Innovación Constante</h3>
            <p className={`${isDarkMode ? 'text-zinc-400' : 'text-gray-600'} leading-relaxed`}>
              Siempre explorando nuevas técnicas, tendencias y herramientas para mantener 
              mis diseños frescos y relevantes.
            </p>
          </div>
        </div>
      </div>

      {/* Cita inspiradora */}
      <div className={`${isDarkMode ? 'bg-gradient-to-r from-zinc-900 to-black border-zinc-800' : 'bg-gradient-to-r from-gray-50 to-gray-100 border-gray-300'} border rounded-2xl p-12 text-center`}>
        <blockquote className={`text-2xl md:text-3xl font-light ${isDarkMode ? 'text-white' : 'text-black'} mb-4 italic`}>
          "El diseño no es solo lo que parece y lo que se siente.
          <br />
          <span className="text-[#c8ff00] font-semibold">El diseño es cómo funciona."</span>
        </blockquote>
        <p className={isDarkMode ? 'text-zinc-500' : 'text-gray-500'}>— Steve Jobs</p>
      </div>
    </div>
  );
}