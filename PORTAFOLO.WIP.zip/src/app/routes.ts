import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { LoginPage } from "./components/LoginPage";
import { AboutPage } from "./components/AboutPage";
import { SkillsPage } from "./components/SkillsPage";
import { ContactPage } from "./components/ContactPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: LoginPage },
      { path: "about", Component: AboutPage },
      { path: "skills", Component: SkillsPage },
      { path: "contact", Component: ContactPage },
    ],
  },
]);
